using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class healthbar : MonoBehaviour
{

    public GameObject Player;
    public float scaleX;
    public float scaleY;
    public float playerCurrentHp;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        playerCurrentHp = Player.GetComponent<PlayerMovement>().playerCurrentHp;
        transform.localScale = new Vector3(playerCurrentHp * scaleX, scaleY, transform.localScale.z);
    }
}
