using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Parallax : MonoBehaviour
{
    private float lengthX, startposX;
    private float lengthY, startposY;
    public GameObject cam;
    public float ParallaxX;
    public float ParallaxY;

    
    // Start is called before the first frame update
    void Start()
    {
        startposX = transform.position.x;
        startposY = transform.position.y;
        lengthX = GetComponent<SpriteRenderer>().bounds.size.x;
        lengthY = GetComponent<SpriteRenderer>().bounds.size.y;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        float temp = (cam.transform.position.x * (1 - ParallaxX));
        float distanceX = (cam.transform.position.x * ParallaxX);

        float distanceY = (cam.transform.position.y * ParallaxY);

        transform.position = new Vector3(startposX + distanceX, startposY + distanceY, transform.position.z);

        if (temp > startposX + lengthX)
        {
            startposX += lengthX;
        }
        else if (temp < startposX - lengthX)
        {
            startposX -= lengthX;
        }
    }
}
