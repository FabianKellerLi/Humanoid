using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public Rigidbody2D rb;
    private Animator animator;
    private BoxCollider2D boxCollider;
    [SerializeField] private float speedX = 800;
    [SerializeField] private float speedY = 15;
    [SerializeField] private float gravityIncrease = -10;
    [SerializeField] private float RaycastBoxDistanceDown = 0.2f;
    Vector2 move;
    public float gravityScale;

    //Enemy Components
    public GameObject enemy;
    
    //Layers
    [SerializeField] private LayerMask groundLayer;
    [SerializeField] private LayerMask wallLayer;
    
    //Wallslide
    private bool isWallSliding;
    [SerializeField] private float wallSlidingSpeed = 0.2f;
    
    //Walljump
    private bool isWallJumping = false;
    private float wallJumpingDirection;
    [SerializeField] private float wallJumpingDuration = 0.1f;
    [SerializeField] private float wallJumpingTime = 0.2f;
    private float wallJumpingCounter;
    private Vector2 wallJumpingPower = new Vector2(20, 15);
    public bool unlockWalljump;
    public GameObject walljump;

    //Dash
    [SerializeField] private float dashSpeed = 10f;
    [SerializeField] private float dashDuration = 0.5f;
    [SerializeField] private float dashCooldown = 0.3f;
    private float dashCooldownTimer = 10000;
    private bool isDashing;
    public bool canDash;
    public bool unlockDash;
    public GameObject dash;

    //Doublejump
    public bool hasDoublejumped;
    public bool unlockDoublejump;
    public GameObject doublejump;      

    //Knockback
    public float KnockbackForceX;
    public float KnockbackForceY;
    public float KnockbackCounter;
    public float KnockbackTime;
    public float KnockbackDirection;
    public bool isGettingKnockback = false;

    //Health
    public int playerMaxHp = 100;
    public int playerCurrentHp;
    public bool takeDamage;

    //Respawn
    public GameObject respawnPoint;




    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        boxCollider = GetComponent<BoxCollider2D>();

        gravityScale = rb.gravityScale;

        playerCurrentHp = playerMaxHp;

        enemy.GetComponent<Enemy>();

        rb.transform.position = respawnPoint.transform.position;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Walljump")
        {
            unlockWalljump = true;
        }

        if (collision.gameObject.tag == "Dash")
        {
            unlockDash = true;
        }

        if (collision.gameObject.tag == "Doublejump")
        {
            unlockDoublejump = true;
        }
    }


    private void FixedUpdate()
    {
        //Quelle-https://www.youtube.com/watch?v=TcranVQUQ5U
        if (!isWallJumping && !isDashing && KnockbackCounter <= 0)
        {
            rb.velocity = new Vector2(move.x * speedX, rb.velocity.y);
        }
        else if (KnockbackCounter > 0)
        {
            rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y);
        }
    }

    // Update is called once per frame
    void Update()
    {
        //test
        //print(-rb.transform.localScale.x);
        //print(wallJumpingDirection);
        //print(wallJumpingCounter);


        float HorizontalInput = Input.GetAxisRaw("Horizontal");

        move = new Vector2(HorizontalInput, Input.GetAxisRaw("Vertical"));

        //Character sprite flip when moving  left/right Quelle-https://www.youtube.com/watch?v=TcranVQUQ5U
        if (!isDashing)
        {
            if (HorizontalInput > 0.01f)
                transform.localScale = Vector2.one;
            else if (HorizontalInput < -0.01f)
                transform.localScale = new Vector2(-1, 1);
        }

        //jump
        if (Input.GetKeyDown(KeyCode.Space) && isGrounded() && !isDashing)
        {
            jump();
        }


        //Set animator parameters

        animator.SetBool("running", HorizontalInput != 0 && isGrounded());
        if (HorizontalInput == 0 || !isGrounded())
        {
            animator.SetBool("running", false);
        }


        animator.SetBool("jumping", !isGrounded() && !isDashing);
        animator.SetBool("onWall", onWall());
        animator.SetBool("dashing", isDashing);
        if (KnockbackCounter <= KnockbackTime)
        {
            animator.SetBool("takeDamage", false);
        }



        //Fallbeschleunigung, falls Space nicht mehr gedr�ckt wird
        if (isGrounded() == false && !Input.GetKey(KeyCode.Space) && !onWall() && !isWallJumping && !isDashing)

        // beeinflusst dash falls Player am fallen ist (gI muss negativ sein)
        {
            //alte Methode: rb.AddForce(new Vector2(0, gravityIncrease));
            //rb.gravityScale = gravityIncrease (gravityIncrease muss positiv sein);
            rb.gravityScale = gravityIncrease;
        }
        else if (!isDashing)
        {
            rb.gravityScale = gravityScale;
        }

        if (unlockWalljump == true)
        {
            wallSlide();
        }



        //Walljump
        if (Input.GetKeyDown(KeyCode.Space) && onWall() && !isGrounded() && unlockWalljump == true)
        {
            wallJump();
        }

        //Doublejump
        if (Input.GetKeyDown(KeyCode.Space) && !isGrounded() && !onWall() && !isDashing && !isGettingKnockback && !hasDoublejumped && unlockDoublejump == true)
        {
            Doublejump();
        }

        //Dash cooldown
        dashCooldownTimer += Time.deltaTime;


        if (unlockDash == true)
        {
            Dash();
        }


        KnockbackCounter -= Time.deltaTime;

        Vector2 direction = new Vector2(transform.position.x - enemy.transform.position.x, 0);

        KnockbackDirection = Mathf.Sign(direction.x);



        //Dash/Doublejump reset
        if (isGrounded())
        {
            canDash = true;
            hasDoublejumped = false;
        }

        if (onWall())
        {
            canDash = true;
            hasDoublejumped = false;
            
        }

        //wallslide animation flippen
        if (!isGrounded() && onWall())
        {
            transform.localScale = new Vector3(transform.localScale.x * -1, 1, 1);
        }
    }


    //Quelle-https://www.youtube.com/watch?v=TcranVQUQ5U
    private void jump()
    {
        rb.velocity = new Vector2(rb.velocity.x, speedY);
        animator.SetTrigger("jump");
    }


    //Quelle-https://www.youtube.com/watch?v=_UBpkdKlJzE&list=PLgOEwFbvGm5o8hayFB6skAfa8Z-mw4dPV&index=3
    private bool isGrounded()
    {
        RaycastHit2D raycastHit = Physics2D.BoxCast(boxCollider.bounds.center, boxCollider.bounds.size, 0, Vector2.down, RaycastBoxDistanceDown, groundLayer);
           return raycastHit.collider != null;
    
    }

    //Quelle-https://www.youtube.com/watch?v=_UBpkdKlJzE&list=PLgOEwFbvGm5o8hayFB6skAfa8Z-mw4dPV&index=3
    private bool onWall()
    {
        RaycastHit2D raycastHit = Physics2D.BoxCast(boxCollider.bounds.center, boxCollider.bounds.size, 0, new Vector2(transform.localScale.x, 0), RaycastBoxDistanceDown, groundLayer);//wallLayer && groundLayer);
        return raycastHit.collider != null;
    
    }

    //Quelle-https://www.youtube.com/watch?v=O6VX6Ro7EtA
    private void wallSlide()
    {
        if (onWall() && !isGrounded() && Input.GetAxisRaw("Horizontal") == Mathf.Sign(transform.localScale.x))
        {
            isWallSliding = true;
            rb.velocity = new Vector2(rb.velocity.x, Mathf.Clamp(rb.velocity.y, -wallSlidingSpeed, float.MaxValue));
        }
        else
        {
            isWallSliding = false;
        }
    }


    //Quelle-https://www.youtube.com/watch?v=O6VX6Ro7EtA
    private void wallJump()
    {
        if (onWall())
        {
            isWallJumping = false;
            wallJumpingDirection = -Mathf.Sign(transform.localScale.x);
            wallJumpingCounter = wallJumpingTime;

            CancelInvoke(nameof(stopWallJump));
        }
        else
        {
            wallJumpingCounter -= Time.deltaTime;
        }

        if(Input.GetKeyDown(KeyCode.Space) && wallJumpingCounter >= 0.01f)
        {
            isWallJumping = true;
            rb.velocity = new Vector2(wallJumpingDirection * wallJumpingPower.x, wallJumpingPower.y);
            wallJumpingCounter = 0;
        }

        Invoke(nameof(stopWallJump), wallJumpingDuration);
    }

    private void stopWallJump()
    {
        isWallJumping = false;
    }

    private void Dash()
    {
        if (Input.GetKeyDown(KeyCode.Mouse1) && dashCooldownTimer > dashCooldown && !onWall() && canDash == true)
        {
            CancelInvoke(nameof(stopDash));
            isDashing = true;
            dashCooldownTimer = 0;
            rb.gravityScale = 0;
            float dashDirection = Mathf.Sign(transform.localScale.x);
            rb.velocity = new Vector2(dashDirection * dashSpeed, 0f);
            canDash = false;
            Invoke(nameof(stopDash), dashDuration);
        }
        
        if (Input.GetKeyDown(KeyCode.Mouse1) && dashCooldownTimer > dashCooldown && onWall() && canDash == true)
        {
            CancelInvoke(nameof(stopDash));
            isDashing = true;
            dashCooldownTimer = 0;
            rb.gravityScale = 0;
            float dashDirection = -Mathf.Sign(transform.localScale.x);
            transform.localScale = new Vector2 (dashDirection * Mathf.Abs(transform.localScale.x), transform.localScale.y);
            rb.velocity = new Vector2(dashDirection * dashSpeed, 0f);
            canDash = false;
            Invoke(nameof(stopDash), dashDuration);
        }


    }

    private void stopDash()
    {
        rb.gravityScale = gravityScale;
        isDashing = false;
    }

    public bool canAttack()
    {
        if (!onWall())
        {
            return true;
        }
        else
        {
            return false;
        }
        
    }

    public void PlayerTakeDamage(int enemyAttackDamage)
    {
        playerCurrentHp -= enemyAttackDamage;

        animator.SetBool("takeDamage", true);

        if (playerCurrentHp <= 0)
        {
            Die();
        }
        else
        {
            Knockback();
        }
        KnockbackCounter = KnockbackTime;
    }

    public void Die()
    {
        transform.position = new Vector2 (respawnPoint.transform.position.x, respawnPoint.transform.position.y);
        rb.velocity = new Vector3(0, 0, 0);
        playerCurrentHp = playerMaxHp;
    }

    public void Knockback()
    {
        isGettingKnockback = true;

        if (KnockbackDirection > 0)
        {
            rb.velocity = new Vector2(KnockbackForceX, KnockbackForceY);
        }
        else if (KnockbackDirection < 0)
        {
            rb.velocity = new Vector2(-KnockbackForceX, KnockbackForceY);
        }

        isGettingKnockback = false;
    }

    private void Doublejump()
    {
        rb.velocity = new Vector2(rb.velocity.x, speedY);
        animator.SetTrigger("jump");
        hasDoublejumped = true;
    }
 
}

//Test ob push jetzt geht