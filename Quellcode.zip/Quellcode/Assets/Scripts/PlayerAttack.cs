using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttack : MonoBehaviour
{
    [SerializeField] private float attackCooldown = 0.3f;
    private Animator animator;
    private PlayerMovement playerMovement;
    private float cooldownTimer = 10000f;
    //public float attackRange
    public LayerMask enemyLayer;
    public Transform attackCornerOne;
    public Transform attackCornerTwo;
    public int playerAttackDamage = 20;
    public Vector2 ACOposition;
    public Vector2 ACTposition;
    public Vector2 ACOpositionDown;
    public Vector2 ACTpositionDown;
    public float pogoStrength;




    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
        playerMovement = GetComponent<PlayerMovement>();

    }

    // Update is called once per frame
    void Update()
    {
        //Quelle-https://www.youtube.com/watch?v=sPiVz1k-fEs
        if (Input.GetKeyDown(KeyCode.Mouse0) && cooldownTimer > attackCooldown && playerMovement.canAttack() && !Input.GetKey(KeyCode.S))
        {
            attack();
            animator.SetBool("attacking", true);
        }
        else if (Input.GetKeyDown(KeyCode.Mouse0) && cooldownTimer > attackCooldown && playerMovement.canAttack() && Input.GetKey(KeyCode.S))
        {
            attackDown();
        }

        cooldownTimer += Time.deltaTime;

        if (Input.GetKey(KeyCode.S))
        {
            attackCornerOne.localPosition = ACOpositionDown;
            attackCornerTwo.localPosition = ACTpositionDown;
        }
        else
        {
            attackCornerOne.localPosition = ACOposition;
            attackCornerTwo.localPosition = ACTposition;
        }

        if (cooldownTimer > attackCooldown)
        {
            animator.SetBool("attacking", false);
        }

    }


    //Quelle-https://www.youtube.com/watch?v=sPiVz1k-fEs
    private void attack()
    {

        //Cooldown
        cooldownTimer = 0;

        //animation abspielen

        //detect enemies in range of attack
        Collider2D[] hitEnemies = Physics2D.OverlapAreaAll(attackCornerOne.position, attackCornerTwo.position, enemyLayer); 

        //Damage the Enemies
        foreach(Collider2D enemy in hitEnemies)
        {
            enemy.GetComponent<Enemy>().EnemyTakeDamage(playerAttackDamage);
            print("hit");
            playerMovement.canDash = true;
        }
    }

    private void attackDown()
    {

        //Cooldown
        cooldownTimer = 0;

        //animation abspielen

        //detect enemies in range of attack
        Collider2D[] hitEnemies = Physics2D.OverlapAreaAll(attackCornerOne.position, attackCornerTwo.position, enemyLayer);

        //Damage the Enemies
        foreach (Collider2D enemy in hitEnemies)
        {
            enemy.GetComponent<Enemy>().EnemyTakeDamage(playerAttackDamage);
            print("hit");
            playerMovement.canDash = true;
            playerMovement.hasDoublejumped = false;
        }

        //Player knockback up if hits enemy or spikes
        foreach (Collider2D enemy in hitEnemies)
        {
            playerMovement.rb.velocity = new Vector2(playerMovement.rb.velocity.x, pogoStrength);
        }
    }




}
