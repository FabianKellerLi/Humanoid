using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public Rigidbody2D enemyRb;
    public Collider2D enemyCollider;
    public int enemyMaxHp = 100;
    public int enemyCurrentHp;
    private Func<Enemy> enemyScript;
    public GameObject player;
    public GameObject Enemy1;
    public SpriteRenderer spriteRenderer;
    public GameObject Death;
    

    public LayerMask playerLayer;
    
    public float movementSpeed;
    public float distance;
    public float reactionDistance;

    public float KnockbackForceX;
    public float KnockbackForceY;
    public float KnockbackCounter;
    public float KnockbackTime;
    public float KnockbackDirection;
    public bool isGettingKnockback = false;

    public float enemyAttackCounter;
    public float enemyAttackTime;
    public float enemyAttackDistance;

    public Transform enemyAttackCornerOne;
    public Transform enemyAttackCornerTwo;
    public int enemyAttackDamage;

    //Player invisible frames
    public float InvisibleDuration;
    public float InvisibleCounter;

    public Animator animator;


    // Start is called before the first frame update
    void Start()
    {
        enemyCurrentHp = enemyMaxHp;
        enemyScript = GetComponent<Enemy>;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "Player" )
        {
            player.GetComponent<PlayerMovement>().PlayerTakeDamage(enemyAttackDamage);
            print("enemyHit");
        }
    }

    // Update is called once per frame
    void Update()
    {
        distance = Vector2.Distance(transform.position, player.transform.position);
        Vector2 direction = new Vector2 (player.transform.position.x - transform.position.x, 0);

        if (distance <= reactionDistance && distance > enemyAttackDistance && (direction.x > 0.1 || direction.x < -0.1) && KnockbackCounter <= 0 && enemyAttackCounter < 0)
        {
            enemyRb.velocity = new Vector2(Mathf.Sign(direction.x) * movementSpeed, enemyRb.velocity.y);
        }
        else if (KnockbackCounter > 0)
        {
            enemyRb.velocity = new Vector2(enemyRb.velocity.x, enemyRb.velocity.y);
        }
        else
        {
            enemyRb.velocity = new Vector2(0, enemyRb.velocity.y);
        }

        KnockbackDirection = -Mathf.Sign(direction.x);

        KnockbackCounter -= Time.deltaTime;

        if (enemyAttackCounter <= 0 && distance <= enemyAttackDistance && KnockbackCounter <= 0)
        {
            EnemyAttack();
        }

        if (enemyAttackCounter <= enemyAttackTime -0.5)
        {
            animator.SetBool("attacking", false);
        }

         enemyAttackCounter -= Time.deltaTime;

        //flip
        if (direction.x < 0)
        {
            transform.localScale = new Vector3(-1, transform.localScale.y, transform.localScale.z);
        }
        else if (direction.x > 0)
        {
            transform.localScale = new Vector3(1, transform.localScale.y, transform.localScale.z);
        }

        //invisible frames timer
        InvisibleCounter -= Time.deltaTime;

        if (enemyRb.velocity.x != 0 && KnockbackCounter <= 0)
        {
            animator.SetBool("walking", true);
        }
        else
        {
            animator.SetBool("walking", false);
        }

    }
    //Quelle-https://www.youtube.com/watch?v=sPiVz1k-fEs
    public void EnemyTakeDamage(int playerAttackDamage)
    {
        enemyCurrentHp -= playerAttackDamage;

        //animation

        if(enemyCurrentHp <= 0)
        {
            Die();
        }

        KnockbackCounter = KnockbackTime;
        KnockBack();
    }

    public void KnockBack()
    {
            isGettingKnockback = true;

            enemyAttackCounter = enemyAttackTime;

            if (KnockbackDirection == 1)
            {
                enemyRb.velocity = new Vector2(KnockbackForceX, KnockbackForceY);
            }
            else if (KnockbackDirection == -1)
            {
                enemyRb.velocity = new Vector2(-KnockbackForceX, KnockbackForceY);
            }
        
    }


    public void Die()
    {
        //animation
        animator.SetBool("died", true);
        spriteRenderer.enabled = !spriteRenderer.enabled;
        transform.position = Death.transform.position;
   
    }

    public void EnemyAttack()
    {

        animator.SetBool("attacking", true);
        //Cooldown
        enemyAttackCounter = enemyAttackTime;

        //animation abspielen

        //detect player in range of attack
        Collider2D[] hitPlayer = Physics2D.OverlapAreaAll(enemyAttackCornerOne.position, enemyAttackCornerTwo.position, playerLayer);

        //Damage the player
        foreach (Collider2D player in hitPlayer)
        {
            player.GetComponent<PlayerMovement>().PlayerTakeDamage(enemyAttackDamage);
            print("enemyHit");
        }
    }
    
  

}

