using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossScript : MonoBehaviour
{
    private GameObject player;
    public GameObject projectile;
    public Transform pojectilePos;
    public GameObject blob;
    public Rigidbody2D rbBoss;
    private int random;

    public float distance;
    public float reactionDistance;
    // Start is called before the first frame update

    private float timer;
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
    }

    // Update is called once per frame
    void Update()
    {

        distance = Vector2.Distance(transform.position, player.transform.position);

        if(distance <= reactionDistance)
        {
            rbBoss.velocity = new Vector2(player.transform.position.x - transform.position.x, 0);
        }
        
        

        timer += Time.deltaTime;

        if (timer > 2 && distance <= reactionDistance)
        {
            timer = 0;
            random = Random.Range(0, 2);

            if (random == 0)
            {
                Shoot();
            }
            if (random == 1)
            {
                Blob();

            }

        }

    }

    void Shoot()
    {
        Instantiate(projectile, pojectilePos.position, Quaternion.identity);
    }

    void Blob()
    {
        Instantiate(blob, pojectilePos.position, Quaternion.identity);
        Instantiate(blob, pojectilePos.position, Quaternion.identity);
        Instantiate(blob, pojectilePos.position, Quaternion.identity);
        Instantiate(blob, pojectilePos.position, Quaternion.identity);
        Instantiate(blob, pojectilePos.position, Quaternion.identity);
    }
}
